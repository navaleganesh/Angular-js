import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public str1;
  public str2;
  constructor() {
  }
  public store(val1,val2){
     this.str1=val1;
     this.str2=val2;
  }
}
