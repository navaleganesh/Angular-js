import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  City =  [
    {name: 'Pune'},
    {name: 'Mumbai'},
    {name: 'Banglore'}
    
  ];

  selectedValue:string;
}
