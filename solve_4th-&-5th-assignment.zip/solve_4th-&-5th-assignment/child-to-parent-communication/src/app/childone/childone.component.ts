import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
//import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-childone',
  templateUrl: './childone.component.html',
  styleUrls: ['./childone.component.css']
})
export class ChildoneComponent implements OnInit {
  
  @Output() public eventObj = new EventEmitter();

  public sendtoParent(){
    this.eventObj.emit('I am child');
  }
  
  constructor() { }

  ngOnInit() {
  }

}
