import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databases',
  templateUrl: './databases.component.html',
  styleUrls: ['./databases.component.css']
})
export class DatabasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
