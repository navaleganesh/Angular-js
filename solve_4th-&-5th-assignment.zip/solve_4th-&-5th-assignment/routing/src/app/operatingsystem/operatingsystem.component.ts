import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operatingsystem',
  templateUrl: './operatingsystem.component.html',
  styleUrls: ['./operatingsystem.component.css']
})
export class OperatingsystemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
