import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-programminglanguages',
  templateUrl: './programminglanguages.component.html',
  styleUrls: ['./programminglanguages.component.css']
})
export class ProgramminglanguagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
