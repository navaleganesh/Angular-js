import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-component',
  templateUrl: './student-component.component.html',
  styleUrls: ['./student-component.component.css']
})
export class StudentComponentComponent implements OnInit {

  public studentArr = [];

  constructor(private _studentObj:StudentService) { }

  ngOnInit() {
    this._studentObj.GetStudentDetails()
    .subscribe(data=>this.studentArr=data);
  }

}
