export interface IStudent
{   
    Id: number,
    Name: String,
    Degree : String,
    Year: number
}