import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singleform',
  templateUrl: './singleform.component.html',
  styleUrls: ['./singleform.component.css']
})
export class SingleformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
