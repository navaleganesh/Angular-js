import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor() { }

GetBookDetails(){
   return[
      {"Name":"Let us C", "Price":500, "Author":"Yashavant Kanetkar", "Pages":800},
      {"Name":"The C++ Programming Language", "Price":1000, "Author":"Bjarne Stroustrup", "Pages":1000},
      {"Name":"Java", "Price":2000, "Author":"James Gosling","Pages":800},
      {"Name":"UNIX", "Price":500, "Author":"Dennis MacAlistair Ritchie","Pages":450},
   ];
  
}

}
